itkMGHImageIO
=============

A copy of the Slicer itkMGHImageIO mechanism for ITK.

The intent of this repository is to extract the itkMGHImageIO from it's embedded Slicer only implementation and make it accessible to any ITK compliant program.

This will be accomplished using the ITKv4 "Remote Module" mechanism as defined at.

http://www.itk.org/Wiki/ITK/Policy_and_Procedures_for_Adding_Remote_Modules


